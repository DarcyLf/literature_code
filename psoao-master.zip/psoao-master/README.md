The running codes for MNIST and CIFAR-10 are released at this time, and other codes will be released when the paper is accepted.

